import { HeroSection } from "@/components/hero-section"
import { ExcellenceSection } from "@/components/excellence-section"
import { PlatformSection } from "@/components/platform-section"
import { CustomerStoriesSection } from "@/components/customer-stories-section"
import { EngageSection } from "@/components/engage-section"
import { CTASection } from "@/components/cta-section"

export default function Home() {
  return (
    <>
      <HeroSection />
      <ExcellenceSection />
      <PlatformSection />
      <CustomerStoriesSection />
      <EngageSection />
      <CTASection />
    </>
  )
}

