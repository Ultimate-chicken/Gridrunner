import Image from "next/image"

export function CustomerStoriesSection() {
  return (
    <section className="py-16 bg-black text-white">
      <div className="container px-4 md:px-6">
        <h2 className="text-3xl font-bold mb-8 text-center">Trusted by the best</h2>
        <div className="mb-12 text-center">
          <p className="text-2xl font-bold">2000+</p>
          <p>Gridrunner customers</p>
        </div>
        <div className="grid gap-8 md:grid-cols-3">
          <div className="bg-zinc-900 p-6 rounded-lg">
            <Image
              src="/placeholder.svg"
              alt="Blackrock Cybersecurity"
              width={300}
              height={200}
              className="mb-4 rounded"
            />
            <h3 className="text-xl font-bold mb-2">Gridrunner Protects Blackrock Cybersecurity</h3>
          </div>
          <div className="bg-zinc-900 p-6 rounded-lg">
            <Image
              src="/placeholder.svg"
              alt="F1 Infrastructure"
              width={300}
              height={200}
              className="mb-4 rounded"
            />
            <h3 className="text-xl font-bold mb-2">Gridrunner Protects F1 Infrastructure</h3>
          </div>
          <div className="bg-zinc-900 p-6 rounded-lg">
            <Image
              src="/placeholder.svg"
              alt="Shannon Airport"
              width={300}
              height={200}
              className="mb-4 rounded"
            />
            <h3 className="text-xl font-bold mb-2">Shannon Airport</h3>
          </div>
        </div>
      </div>
    </section>
  )
}

