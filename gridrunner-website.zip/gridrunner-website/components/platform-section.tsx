import { Button } from "@/components/ui/button"

export function PlatformSection() {
  return (
    <section className="py-16 bg-white">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold">Stay ahead of adversaries</h2>
        </div>
        <div className="grid gap-8 md:grid-cols-3">
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-blue-600">Network Security</h3>
            <p className="text-zinc-600">
              Shield your business from cyber threats with cutting-edge network security! Our powerful solutions safeguard your data, block hackers, and ensure seamless connectivity—all while giving you peace of mind. Stay protected, stay connected, and stay ahead with the ultimate defense for your network.
            </p>
            <Button variant="outline" className="text-blue-600 border-blue-600">
              Explore the Platform →
            </Button>
          </div>
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-green-600">AI-Driven Sustainable Approach</h3>
            <p className="text-zinc-600">
              Transform your operations with AegisAI, the smart solution for a greener future. Harness the power of AI to optimize resources, reduce waste, and lower your carbon footprint—all while boosting efficiency. With AegisAI, sustainability isn't just a goal; it's a competitive advantage. Join the movement for a smarter, cleaner tomorrow!
            </p>
            <Button variant="outline" className="text-green-600 border-green-600">
              Explore the Platform →
            </Button>
          </div>
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-red-600">Threat Intel & Incident Response</h3>
            <p className="text-zinc-600">
              Stay one step ahead of cybercriminals with our proactive Threat Intelligence & Incident Response solutions. Powered by real-time insights and advanced tools, we identify threats before they strike and respond swiftly to protect your business. Minimize downtime, mitigate risks, and safeguard your reputation with a defense strategy you can count on!
            </p>
            <Button variant="outline" className="text-red-600 border-red-600">
              Explore the Platform →
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

