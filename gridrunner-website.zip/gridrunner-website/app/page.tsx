import { HeroSection } from "@/components/hero-section"
import { ExcellenceSection } from "@/components/excellence-section"

export default function Home() {
  return (
    <>
      <HeroSection />
      <ExcellenceSection />
    </>
  )
}

